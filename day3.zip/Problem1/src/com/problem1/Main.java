package com.problem1;

public class Main {
    public static void main(String[] args) {
	subjects sb=new subjects();
        System.out.println("student had "+sb.grade()+"%");
    }
}
