package com.problem2;

public class Main {

    public static void main(String[] args) {
	    Employee e=new Employee();
        System.out.println(e.Tax());
    }
}
