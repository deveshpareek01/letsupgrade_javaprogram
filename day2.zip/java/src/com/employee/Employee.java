package com.employee;

public class Employee {
    public String name=new String();
    public int age;
    public String city=new String();
    public void show() {
        System.out.println("The name is "+name);
        System.out.println("The city is "+city);
        System.out.println("The age is "+age);
    }
}
