package com.avanger;
import java.security.PublicKey;
import java.util.Scanner;

public class Avangers {
    private String name,age,power,weapon,planet;
    Scanner sc=new Scanner(System.in);
    public void getDetails()
    {
        System.out.println("Enter name");
        name=sc.nextLine();
        System.out.println("Enter age");
        age=sc.nextLine();
        System.out.println("Enter power");
        power=sc.nextLine();
        System.out.println("Enter weapon");
        weapon=sc.nextLine();
        System.out.println("Enter Planet");
        planet=sc.nextLine();
    }
    public void DisplayDetails()
    {
        System.out.println("Name : "+name+", age : "+age+", power : "+power+", weapon : "+weapon+", planet : "+planet);
    }


}

