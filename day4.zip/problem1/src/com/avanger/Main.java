package com.avanger;

public class Main {

    public static void main(String[] args) {
	    Avangers[] Ava=new Avangers[5];
	    for(int i=0;i<5;i++) {
            Ava[i] = new Avangers();
            Ava[i].getDetails();
            Ava[i].DisplayDetails();
        }
    }
}
