package com.problem2;
import java.util.Scanner;

public class Employee {
    Scanner sc=new Scanner(System.in);
    public String Tax()
    {
        String name;
        int db;
        int mb;
        int by;
        float ms;
        float tax;
        System.out.println("Enter Employee name : ");
        name=sc.nextLine();
        System.out.println("Enter date of birth : ");
        db=sc.nextInt();
        System.out.println("Enter month of birth : ");
        mb=sc.nextInt();
        System.out.println("Enter year if birth : ");
        by=sc.nextInt();
        System.out.println("Enter monthly sallery :");
        ms=sc.nextFloat();
        float as=ms*12;
        if(as>=500000f/12)
        {
            tax=as/5;
        }
        else if(as>=400000f && as<500000f)
        {
            tax=(as*15)/100;
        }
        else if (as>=300000f && as<400000f)
        {
            tax=as/10;
        }
        else if( as>=200000f && as<300000f)
        {
            tax=as/20;
        }
        else
        {
            tax=0f;
        }
        int age=2020-by;

        return "Hello "+name+" your current age is "+age+" your annual salary is "+as+" and your total tax amount is "+tax;
    }
}
