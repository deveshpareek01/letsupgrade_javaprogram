package com.problem1;
import java.util.Scanner;
public class subjects {
    float s1,s2,s3,s4,s5,per,per1;
    public float percentage()
    {
        System.out.println("Enter marks! of s1,s2,s3,s4,s5 ");
        Scanner sc=new Scanner(System.in);
        s1=sc.nextFloat();
        s2=sc.nextFloat();
        s3=sc.nextFloat();
        s4=sc.nextFloat();
        s5=sc.nextFloat();
        per=(s1+s2+s3+s4+s5)/5;
        return per;
    }
    public String grade()
    {
      per1 = percentage();
      if(per1<33f)
      {
          return ("fail with percentage"+per1);
      }
      else if(per1>=33f && per<44f )
      {
          return ("Third grade with percentage "+per1);
      }
      else if(per1>=44f && per<60f)
      {
          return ("Second grade with percentage "+per1);
      }
      else
      {
          return ("First grade with percentage "+per1);
      }
    }
}
