package com.sums;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
	    int[] arr=new int[5];
	    for(int i=0;i<5;i++)
        {
            System.out.println("Enter element");
            arr[i]=sc.nextInt();
        }
	    int t=0;
	    for(int i=0;i<5;i++)
        {
            t=t+arr[i];
        }
        System.out.println("Sum of element : "+t);
    }
}
